#!/bin/bash
echo "Running dummy tests..."
exit 0
