# DevOps Engineer Assignment

## Overview
This project sets up automated infrastructure, CI/CD pipeline, and monitoring using Terraform, Jenkins, and AWS (can be adapted to GCP).

## Structure
- **infra/**: Terraform infrastructure code
- **jenkins/**: Jenkins CI/CD pipeline
- **app/**: Simple web app and tests
- **monitoring/**: CloudWatch agent config and alert setup

## Setup Instructions
1. Navigate to `infra/` and run `terraform init && terraform apply`
2. Setup Jenkins using the `Jenkinsfile`
3. Configure CloudWatch alerts using files in `monitoring/`
